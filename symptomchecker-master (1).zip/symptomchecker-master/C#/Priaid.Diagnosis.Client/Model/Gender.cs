﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Priaid.Diagnosis.Client.Model
{
    /// <summary>
    /// Person gender
    /// </summary>
    public enum Gender
    {
        Male = 1,
        Female = 2
    }
}
