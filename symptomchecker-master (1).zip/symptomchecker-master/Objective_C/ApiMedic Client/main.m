//
//  main.m
//  ApiMedic Client
//
//  Created by aplimpton on 31.3.2017.
//  Copyright © 2017 Priaid. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
